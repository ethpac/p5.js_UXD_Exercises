function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  stroke('black');
  strokeWeight(100);
  
  point(75,200);
  point(200, 200);
  point(325, 200);
}