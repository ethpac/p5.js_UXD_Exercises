function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  stroke('black');
  
  strokeWeight(100);
  
  point(75,200);
  point(200, 200);
  point(325, 200);
  
  strokeWeight(20);
  
  point(13,150);
  point(13,200);
  point(13,250);
  
  point(137,150);
  point(137,200);
  point(137,250);
  
  point(262,150);
  point(262,200);
  point(262,250);
  
  
  point(387,150);
  point(387,200);
  point(387,250);
  
}