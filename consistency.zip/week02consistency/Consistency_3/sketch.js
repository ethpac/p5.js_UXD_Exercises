function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  stroke('black');
  
  strokeWeight(100);
  
  point(75,200);
  point(200, 200);
  point(325, 200);
  
  strokeWeight(20);
  
  point(13,150);
  point(13,200);
  point(13,250);
  
  point(137,150);
  point(137,200);
  point(137,250);
  
  point(262,150);
  point(262,200);
  point(262,250);
  
  
  point(387,150);
  point(387,200);
  point(387,250);
  
  strokeWeight(30);
  
  point(55,120);
  point(75,120);
  point(95,120);
  
  point(55,280);
  point(75,280);
  point(95,280);
  
  point(180,120);
  point(200,120);
  point(220,120);
  
  point(180,280);
  point(200,280);
  point(220,280);
  
  point(305,120);
  point(325,120);
  point(345,120);
  
  point(305,280);
  point(325,280);
  point(345,280);

}